﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class Tell
        {
            public int Day;
            public double Time;
            public double Cost;
            public  Tell (int d, double time, double cost)
            {
                Day = d;
                Time = time;
                Cost = cost;
            }
            public double Calculate()
            {
                double resultingCost = Cost*Time;

                if (Day == 6 || Day == 7)
                {
                    resultingCost *= 0.9;
                }

                return resultingCost;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int d = (int)(numericUpDown1.Value);
            double time = Convert.ToDouble(textBox1.Text);
            double cost = Convert.ToDouble(textBox2.Text);

            Tell allcost = new Tell(d,time,cost);
            double result = allcost.Calculate();
            label5.Text = result.ToString();

        }
    }
}
