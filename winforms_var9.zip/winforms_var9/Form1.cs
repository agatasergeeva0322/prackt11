﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace winforms_var9
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();
        }

        //public class Figure
        //{
        //}   
        public class Rectangle
        {

            public double width;
            public double height;

                public Rectangle(double a, double b)
                {
                    width = a;
                    height = b;
                }

                public double Perimeter()
                {
                    return 2 * (width + height);
                }

                public double Area()
                {
                    return (width * height);
                }

            }
            public class Circle
        {
            public double Radius;

            public Circle(double radius)
            {
                Radius = radius;
            }

            public double Perimeter()
            {
                return 2 * Math.PI * Radius ;
            }

            public double Area()
            {
                return Math.PI * Math.Pow(Radius, 2);
            }

        }
        public class Triangle
        {
            public double A;
            public double B;
            public double C;

            public Triangle(double a, double b, double c)
            {
                A = a;
                B = b;
                C = c;
            }

            public double Perimeter()
            {
                return A + B + C;
            }

            public double Area()
            {
                double p = Math.Round(((A + B + C) / 2),2);
                return Math.Round((Math.Sqrt(p*(p-A)*(p-B)*(p-C))),2) ;
            }

        }

        private void button2_Click (object sender, EventArgs e, string _figure_) //рассчитать
        {
            int kolvo = (int) (numericUpDown1.Value);
            if (_figure_ == "Прямоугольник")
            {

                    double a = Convert.ToDouble(textBox1.Text);
                    double b = Convert.ToDouble(textBox2.Text);

                    Rectangle rectangle = new Rectangle(a,b);
                    double perimeter = rectangle.Perimeter();
                    double area = rectangle.Area();
                    label12.Text = perimeter.ToString();
                    label13.Text = area.ToString();

            }
            else if (_figure_ == "Круг")
            {
                double radius = Convert.ToDouble(textBox2.Text);

                Circle circle = new Circle(radius);
                double perimeter = circle.Perimeter();
                double area = circle.Area();
                label12.Text = perimeter.ToString();
                label13.Text = area.ToString();
            }
            else
            {
                double a = Convert.ToDouble(textBox1.Text);
                double b = Convert.ToDouble(textBox2.Text);
                double c = Convert.ToDouble(textBox3.Text);

                Triangle triangle = new Triangle(a,b,c);
                double perimeter = triangle.Perimeter();
                double area = triangle.Area();
                label12.Text = perimeter.ToString();
                label13.Text = area.ToString();

            }


        }
        private void button1_Click(object sender, EventArgs e) //выбор фигуры
        {
            string _figure_ = comboBox1.Text;

            if (_figure_ == "Прямоугольник")
            {
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                //
                label8.Visible = false;
                label9.Visible = false;
                label6.Visible = false;
                label7.Visible = false;
            }
            else if (_figure_ == "Круг")
            {
                label8.Visible = true;
                label9.Visible = true;
                textBox2.Visible = true;
                //
                label3.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
            }
            else
            {
                label3.Visible = true;
                label4.Visible = true;
                label6.Visible = true;
                label7.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                //
                label8.Visible = false;
                label9.Visible = false;
            }
        }
    }
}
